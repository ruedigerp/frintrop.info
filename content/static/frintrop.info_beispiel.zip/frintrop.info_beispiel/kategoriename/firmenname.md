###### Kontaktdaten auf einem Blick

<Firmenname>

<Strasse>

<PLZ> <ORT>

Telefon: [<+49 201 123456>](tel:<+49201123456>)

Email: [<E-Mail Adresse](mailto:<E-Mail Adresse>)

Homepage: [<Homepage Adresse>](<Homepage Adresse>)

Facebook: [<Facebook Adresse>](<Facebook Adresse>)

Instagramm: [<Instagram Adresse>](<Instagram Adresse>)

### Öffnungszeiten

<Zusätzlicher Infotext falls gewünscht>

Montag: <von> Uhr - <bis> Uhr

Dienstag: <von> Uhr - <bis> Uhr

Mittwoch: <von> Uhr - <bis> Uhr

Donnerstag: <von> Uhr - <bis> Uhr

Freitag: <von> Uhr - <bis> Uhr

Samstag: <von> Uhr - <bis> Uhr

### <Firmenname>

<Bildername falls gewünscht>

<Beschreibungtext falls gewünscht>

<Beschreibungtext falls gewünscht>

<Bildergallerie falls gewünscht>

<Beschreibungtext falls gewünscht>

<Beschreibungtext falls gewünscht>
